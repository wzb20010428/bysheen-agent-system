from __future__ import annotations

from pathlib import Path

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles

from app.core.config import get_settings
from app.core.store import store
from app.models.schemas import JobCreateRequest, JobListResponse, JobRecord, RunResponse
from app.services.job_runner import job_runner

settings = get_settings()
app = FastAPI(title=settings.app_name, version="0.1.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.mount("/static/images", StaticFiles(directory=settings.images_path), name="images")


@app.get("/api/health")
async def health() -> dict:
    return {"ok": True, "app": settings.app_name, "env": settings.env}


@app.post("/api/jobs", response_model=JobRecord)
async def create_job(req: JobCreateRequest) -> JobRecord:
    job = job_runner.create_job(req)
    if req.auto_run:
        await job_runner.run_job(job.id)
        refreshed = store.get(job.id)
        return refreshed or job
    return job


@app.get("/api/jobs", response_model=JobListResponse)
async def list_jobs(limit: int = 30) -> JobListResponse:
    return JobListResponse(items=store.list(limit=limit))


@app.get("/api/jobs/{job_id}", response_model=JobRecord)
async def get_job(job_id: str) -> JobRecord:
    job = store.get(job_id)
    if not job:
        raise HTTPException(status_code=404, detail="任务不存在")
    return job


@app.post("/api/jobs/{job_id}/run", response_model=RunResponse)
async def run_job(job_id: str) -> RunResponse:
    try:
        return await job_runner.run_job(job_id)
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


@app.get("/api/jobs/{job_id}/export")
async def download_export(job_id: str) -> FileResponse:
    job = store.get(job_id)
    if not job:
        raise HTTPException(status_code=404, detail="任务不存在")
    if not job.export_file:
        raise HTTPException(status_code=404, detail="该任务还没有生成 Excel")
    path = Path(job.export_file)
    if not path.exists():
        raise HTTPException(status_code=404, detail="Excel 文件不存在")
    return FileResponse(
        path,
        filename=path.name,
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    )


@app.post("/api/demo-job", response_model=JobRecord)
async def create_demo_job() -> JobRecord:
    demo = JobCreateRequest.model_validate(
        {
            "target_market": "SG",
            "category_hint": "Home & Kitchen",
            "source": {
                "mode": "manual",
                "manual_product": {
                    "source_url": "https://detail.1688.com/demo",
                    "raw_title": "厂家直销 不锈钢厨房置物架 多层收纳架 落地微波炉架",
                    "raw_description": "厨房收纳置物架，层板结实，适合厨房、客厅、储物间使用。材质：不锈钢。层数：4层。颜色：银色。",
                    "price_cny": 39.9,
                    "images": [],
                    "specs": {"材质": "不锈钢", "层数": "4层", "颜色": "银色", "使用场景": "厨房/客厅/储物间"},
                    "supplier_name": "Demo Supplier",
                },
            },
        }
    )
    return job_runner.create_job(demo)
