from __future__ import annotations

import json
from typing import Any, Dict, List, Optional

import httpx

from app.core.config import get_settings
from app.models.schemas import TokenUsage


class AIClient:
    """OpenAI-compatible Chat Completions client.

    The project is runnable without an API key. When no key is configured,
    callers should use fallback behavior.
    """

    def __init__(self) -> None:
        self.settings = get_settings()

    @property
    def enabled(self) -> bool:
        return bool(self.settings.ai_api_key.strip())

    async def chat_json(self, system: str, user: str, schema_hint: str = "") -> tuple[Optional[Dict[str, Any]], TokenUsage]:
        usage = TokenUsage()
        if not self.enabled:
            return None, usage

        url = self.settings.ai_base_url.rstrip("/") + "/chat/completions"
        headers = {
            "Authorization": f"Bearer {self.settings.ai_api_key}",
            "Content-Type": "application/json",
        }
        messages: List[Dict[str, str]] = [
            {"role": "system", "content": system},
            {"role": "user", "content": user + ("\n\nReturn JSON only. " + schema_hint if schema_hint else "\n\nReturn JSON only.")},
        ]
        payload = {
            "model": self.settings.ai_model,
            "messages": messages,
            "temperature": 0.3,
            "response_format": {"type": "json_object"},
        }
        async with httpx.AsyncClient(timeout=self.settings.ai_timeout_seconds) as client:
            response = await client.post(url, headers=headers, json=payload)
            response.raise_for_status()
            data = response.json()

        raw = data.get("choices", [{}])[0].get("message", {}).get("content", "{}")
        api_usage = data.get("usage", {}) or {}
        usage.prompt_tokens = int(api_usage.get("prompt_tokens", 0) or 0)
        usage.completion_tokens = int(api_usage.get("completion_tokens", 0) or 0)
        usage.total_tokens = int(api_usage.get("total_tokens", 0) or 0)
        try:
            return json.loads(raw), usage
        except json.JSONDecodeError:
            cleaned = raw.strip().removeprefix("```json").removeprefix("```").removesuffix("```").strip()
            return json.loads(cleaned), usage
