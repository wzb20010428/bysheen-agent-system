from __future__ import annotations

import json
import threading
from datetime import datetime
from pathlib import Path
from typing import List, Optional

from app.core.config import get_settings
from app.models.schemas import AgentStage, JobRecord, JobStatus


class JsonJobStore:
    """Simple JSON file store for MVP. Replace with PostgreSQL in production."""

    def __init__(self) -> None:
        self.settings = get_settings()
        self._lock = threading.RLock()

    def _path(self, job_id: str) -> Path:
        return self.settings.jobs_path / f"{job_id}.json"

    def save(self, job: JobRecord) -> JobRecord:
        with self._lock:
            job.updated_at = datetime.utcnow()
            data = job.model_dump(mode="json")
            self._path(job.id).write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
        return job

    def get(self, job_id: str) -> Optional[JobRecord]:
        path = self._path(job_id)
        if not path.exists():
            return None
        data = json.loads(path.read_text(encoding="utf-8"))
        return JobRecord.model_validate(data)

    def list(self, limit: int = 50) -> List[JobRecord]:
        files = sorted(self.settings.jobs_path.glob("*.json"), key=lambda p: p.stat().st_mtime, reverse=True)
        items: List[JobRecord] = []
        for path in files[:limit]:
            try:
                items.append(JobRecord.model_validate(json.loads(path.read_text(encoding="utf-8"))))
            except Exception:
                continue
        return items

    def log(self, job: JobRecord, message: str) -> JobRecord:
        timestamp = datetime.utcnow().strftime("%H:%M:%S")
        job.logs.append(f"[{timestamp}] {message}")
        return self.save(job)

    def set_stage(self, job: JobRecord, stage: AgentStage) -> JobRecord:
        job.stage = stage
        return self.save(job)

    def set_status(self, job: JobRecord, status: JobStatus) -> JobRecord:
        job.status = status
        return self.save(job)


store = JsonJobStore()
