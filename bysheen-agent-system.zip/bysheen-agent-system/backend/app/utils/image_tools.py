from __future__ import annotations

import hashlib
from pathlib import Path
from typing import Optional, Tuple
from urllib.parse import urlparse

import httpx
from PIL import Image, ImageOps, ImageFilter

from app.core.config import get_settings


def safe_ext_from_url(url: str) -> str:
    suffix = Path(urlparse(url).path).suffix.lower()
    if suffix in {".jpg", ".jpeg", ".png", ".webp"}:
        return suffix
    return ".jpg"


def filename_for_url(url: str) -> str:
    h = hashlib.sha256(url.encode("utf-8")).hexdigest()[:18]
    return f"{h}{safe_ext_from_url(url)}"


async def download_image(url: str, job_id: str) -> Optional[Path]:
    settings = get_settings()
    target_dir = settings.images_path / job_id
    target_dir.mkdir(parents=True, exist_ok=True)
    target = target_dir / filename_for_url(url)
    if target.exists() and target.stat().st_size > 0:
        return target

    try:
        async with httpx.AsyncClient(timeout=settings.request_timeout_seconds, follow_redirects=True) as client:
            resp = await client.get(url, headers={"User-Agent": "Mozilla/5.0 BysheenAgent/1.0"})
            resp.raise_for_status()
            ctype = resp.headers.get("content-type", "")
            if "image" not in ctype and len(resp.content) < 1024:
                return None
            target.write_bytes(resp.content)
        return target
    except Exception:
        return None


def inspect_image(path: Path) -> Tuple[Optional[int], Optional[int], float, list[str]]:
    notes: list[str] = []
    try:
        with Image.open(path) as im:
            width, height = im.size
            score = 0.0
            if width >= 800 and height >= 800:
                score += 40
            elif width >= 500 and height >= 500:
                score += 25
            else:
                notes.append("图片尺寸偏小，建议使用 800x800 以上主图")
                score += 10
            ratio = width / max(height, 1)
            if 0.8 <= ratio <= 1.25:
                score += 30
            else:
                notes.append("主图比例不是正方形，建议裁剪为 1:1")
                score += 10
            if im.mode in ("RGB", "RGBA"):
                score += 10
            score += min(20, path.stat().st_size / 50_000)
            return width, height, min(score, 100), notes
    except Exception as exc:
        return None, None, 0, [f"图片无法解析：{exc}"]


def make_square_preview(path: Path) -> Optional[Path]:
    """Create a basic square preview with white background and soft shadow.

    This is intentionally conservative: it does not pretend to remove watermarks.
    Replace this function with OCR/inpainting/COS upload in production.
    """
    try:
        out = path.with_name(path.stem + "_square.jpg")
        with Image.open(path) as im:
            im = im.convert("RGBA")
            im.thumbnail((900, 900))
            canvas = Image.new("RGBA", (1000, 1000), (255, 255, 255, 255))
            shadow = Image.new("RGBA", im.size, (0, 0, 0, 90))
            shadow = shadow.filter(ImageFilter.GaussianBlur(18))
            x = (1000 - im.width) // 2
            y = (1000 - im.height) // 2
            canvas.alpha_composite(shadow, (x + 12, y + 18))
            canvas.alpha_composite(im, (x, y))
            canvas = ImageOps.exif_transpose(canvas.convert("RGB"))
            canvas.save(out, quality=92)
            return out
    except Exception:
        return None
