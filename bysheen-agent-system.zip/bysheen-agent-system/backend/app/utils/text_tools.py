from __future__ import annotations

import re
from typing import Iterable, List

NOISE_WORDS = [
    "厂家直销", "一件代发", "批发", "源头工厂", "现货", "包邮", "1688", "阿里巴巴",
    "跨境专供", "爆款", "网红", "抖音同款", "新款", "特价", "清仓", "支持定制",
]

MARKET_LANG = {
    "SG": "en",
    "MY": "en",
    "PH": "en",
    "TH": "th",
    "VN": "vi",
    "ID": "id",
    "US": "en",
    "UK": "en",
}


def normalize_space(text: str) -> str:
    return re.sub(r"\s+", " ", (text or "")).strip()


def clean_chinese_title(title: str) -> str:
    title = normalize_space(title)
    for w in NOISE_WORDS:
        title = title.replace(w, "")
    title = re.sub(r"[【】\[\]（）(){}]+", " ", title)
    title = re.sub(r"\s+", " ", title).strip(" -_丨|")
    return title[:180]


def unique_keep_order(items: Iterable[str]) -> List[str]:
    seen = set()
    result = []
    for item in items:
        key = normalize_space(item)
        if not key or key in seen:
            continue
        seen.add(key)
        result.append(key)
    return result


def guess_language_for_market(market: str) -> str:
    return MARKET_LANG.get((market or "SG").upper(), "en")


def build_fallback_keywords(title: str) -> List[str]:
    words = re.split(r"[\s,，/|;；]+", title)
    return [w for w in unique_keep_order(words) if 2 <= len(w) <= 30][:8]
