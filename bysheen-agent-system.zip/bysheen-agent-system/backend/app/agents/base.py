from __future__ import annotations

from abc import ABC, abstractmethod

from app.core.store import JsonJobStore, store
from app.models.schemas import JobRecord


class Agent(ABC):
    name: str = "Agent"

    def __init__(self, job_store: JsonJobStore | None = None) -> None:
        self.store = job_store or store

    async def log(self, job: JobRecord, message: str) -> JobRecord:
        return self.store.log(job, f"{self.name}: {message}")

    @abstractmethod
    async def run(self, job: JobRecord) -> JobRecord:
        raise NotImplementedError
