"""Optional human-assisted uploader skeleton.

This module is intentionally not wired into the default workflow.
It is only for authorized manual assistance where the seller is logged in by themselves.
It must not bypass CAPTCHA, login, platform risk controls, or automate against platform rules.

Install manually if needed:
    pip install playwright
    playwright install chromium
"""

from __future__ import annotations

from pathlib import Path
from typing import Optional


class BrowserAssistedUploader:
    def __init__(self, profile_dir: str = "./browser-profile") -> None:
        self.profile_dir = Path(profile_dir)

    async def open_tiktok_seller_center(self, url: str = "https://seller.tiktokglobalshop.com/") -> None:
        try:
            from playwright.async_api import async_playwright
        except ImportError as exc:
            raise RuntimeError("请先安装 playwright：pip install playwright && playwright install chromium") from exc

        async with async_playwright() as p:
            context = await p.chromium.launch_persistent_context(
                user_data_dir=str(self.profile_dir),
                headless=False,
                viewport={"width": 1440, "height": 1000},
            )
            page = await context.new_page()
            await page.goto(url)
            print("请在浏览器中手动登录和操作。系统不会绕过验证码或风控。")
            await page.wait_for_timeout(60 * 60 * 1000)
            await context.close()
