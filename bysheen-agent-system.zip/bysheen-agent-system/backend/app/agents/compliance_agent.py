from __future__ import annotations

import re

from app.agents.base import Agent
from app.models.schemas import ComplianceIssue, JobRecord


class ComplianceAgent(Agent):
    name = "ComplianceAgent"

    PROHIBITED = [
        "cure", "treat disease", "guaranteed", "100%", "replica", "fake", "counterfeit",
        "best in the world", "medical", "weight loss", "whitening injection",
    ]

    async def run(self, job: JobRecord) -> JobRecord:
        if not job.localized_product:
            raise ValueError("缺少 localized_product，无法合规检查")
        await self.log(job, "开始 TikTok Shop 基础合规检查")

        issues: list[ComplianceIssue] = []
        p = job.localized_product

        if not p.title:
            issues.append(ComplianceIssue(level="error", code="TITLE_EMPTY", message="商品标题为空", suggestion="补充英文/目标语言标题"))
        if len(p.title) > 140:
            issues.append(ComplianceIssue(level="warning", code="TITLE_TOO_LONG", message="标题偏长", suggestion="建议控制在 140 个字符以内"))
        if re.search(r"[\U0001F300-\U0001FAFF]", p.title):
            issues.append(ComplianceIssue(level="warning", code="EMOJI_IN_TITLE", message="标题包含 emoji", suggestion="跨境平台标题建议不要使用 emoji"))

        all_text = f"{p.title}\n{' '.join(p.bullet_points)}\n{p.description}".lower()
        for word in self.PROHIBITED:
            if word in all_text:
                issues.append(ComplianceIssue(level="error", code="SENSITIVE_WORD", message=f"检测到敏感词：{word}", suggestion="删除或替换为客观描述"))

        if len(job.images) == 0:
            issues.append(ComplianceIssue(level="warning", code="NO_IMAGE", message="没有可用商品图片", suggestion="至少提供 1 张 800x800 主图"))
        elif job.images[0].score < 55:
            issues.append(ComplianceIssue(level="warning", code="LOW_MAIN_IMAGE_SCORE", message="主图质量评分偏低", suggestion="建议换成正方形、高清、白底或场景清晰图"))

        if len(p.description) < 80:
            issues.append(ComplianceIssue(level="warning", code="DESC_SHORT", message="详情描述过短", suggestion="补充材质、尺寸、使用场景、包装清单等信息"))

        job.compliance_issues = issues
        errors = len([x for x in issues if x.level == "error"])
        await self.log(job, f"合规检查完成：{len(issues)} 个问题，其中 error {errors} 个")
        return self.store.save(job)
