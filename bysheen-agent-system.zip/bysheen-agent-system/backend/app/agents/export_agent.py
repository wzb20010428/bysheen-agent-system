from __future__ import annotations

from pathlib import Path

from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment
from openpyxl.utils import get_column_letter

from app.agents.base import Agent
from app.core.config import get_settings
from app.models.schemas import JobRecord


class ExportAgent(Agent):
    name = "ExportAgent"

    HEADERS = [
        "Product Name",
        "Category",
        "Brand",
        "Description",
        "Key Selling Points",
        "Search Keywords",
        "Price CNY",
        "Main Image URL",
        "Gallery Image URLs",
        "Source URL",
        "Target Market",
        "Attributes JSON",
        "Compliance Status",
        "Compliance Issues",
        "Scene Image Prompt",
        "Marketing Image Prompt",
    ]

    async def run(self, job: JobRecord) -> JobRecord:
        if not job.localized_product or not job.cleaned_product:
            raise ValueError("缺少商品数据，无法导出")
        await self.log(job, "开始导出 TikTok Shop 批量上架 Excel")

        settings = get_settings()
        out = settings.outputs_path / f"tiktok_import_{job.id}.xlsx"
        self._write_workbook(job, out)
        job.export_file = str(out)
        await self.log(job, f"Excel 导出完成：{out.name}")
        return self.store.save(job)

    def _write_workbook(self, job: JobRecord, path: Path) -> None:
        p = job.localized_product
        raw = job.cleaned_product
        assert p is not None and raw is not None

        wb = Workbook()
        ws = wb.active
        ws.title = "TikTok Import"
        help_ws = wb.create_sheet("Readme")

        ws.append(self.HEADERS)
        for cell in ws[1]:
            cell.font = Font(bold=True, color="FFFFFF")
            cell.fill = PatternFill("solid", fgColor="222222")
            cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)

        main = next((x for x in job.images if x.role == "main"), None)
        gallery = [x.public_url or x.original_url for x in job.images if x.role != "main"]
        issue_errors = [x for x in job.compliance_issues if x.level == "error"]
        status = "BLOCKED" if issue_errors else ("NEED_REVIEW" if job.compliance_issues else "READY")
        issue_text = " | ".join([f"[{x.level}] {x.code}: {x.message}" for x in job.compliance_issues])

        import json
        row = [
            p.title,
            p.category or job.category_hint or "",
            get_settings().export_brand_name,
            p.description,
            "\n".join(p.bullet_points),
            ", ".join(p.search_keywords),
            raw.price_cny,
            (main.public_url or main.original_url) if main else "",
            "\n".join(gallery),
            raw.source_url or "",
            job.target_market,
            json.dumps(p.attributes, ensure_ascii=False),
            status,
            issue_text,
            job.scene_image_prompt or "",
            job.marketing_image_prompt or "",
        ]
        ws.append(row)

        widths = [32, 22, 16, 55, 45, 35, 12, 45, 55, 35, 14, 40, 18, 55, 55, 55]
        for idx, width in enumerate(widths, start=1):
            ws.column_dimensions[get_column_letter(idx)].width = width
        for row_cells in ws.iter_rows(min_row=2):
            for cell in row_cells:
                cell.alignment = Alignment(wrap_text=True, vertical="top")
        ws.freeze_panes = "A2"

        help_ws.append(["说明", "内容"])
        help_ws.append(["用途", "这是系统生成的 TikTok Shop 批量上架中间模板，可继续映射到 TikTok 官方模板字段。"])
        help_ws.append(["图片", "如需正式上传，请把本地图片上传到 COS/S3/CDN 后替换为公网 URL。"])
        help_ws.append(["合规", "READY 可直接复核，NEED_REVIEW 建议人工检查，BLOCKED 需要先修复 error。"])
        help_ws.append(["注意", "不同国家站点的官方模板字段会变化，请以后端 export_agent.py 的 HEADERS 做字段映射扩展。"])
        help_ws.column_dimensions["A"].width = 18
        help_ws.column_dimensions["B"].width = 100
        for cell in help_ws[1]:
            cell.font = Font(bold=True)
        wb.save(path)
