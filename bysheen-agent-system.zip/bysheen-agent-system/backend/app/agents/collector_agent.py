from __future__ import annotations

from typing import List
from urllib.parse import urljoin

import httpx
from bs4 import BeautifulSoup

from app.agents.base import Agent
from app.core.config import get_settings
from app.models.schemas import JobRecord, RawProduct, SourceMode
from app.utils.text_tools import normalize_space, unique_keep_order


class CollectorAgent(Agent):
    name = "CollectorAgent"

    async def run(self, job: JobRecord) -> JobRecord:
        source = job.source
        await self.log(job, f"开始采集，输入模式：{source.mode}")

        if source.mode == SourceMode.manual:
            if not source.manual_product:
                raise ValueError("manual 模式必须提供 manual_product")
            product = source.manual_product
            product.category_hint = product.category_hint or job.category_hint
            job.raw_product = product
            await self.log(job, "已读取手动商品数据")
            return self.store.save(job)

        if source.mode == SourceMode.url:
            if not source.url:
                raise ValueError("url 模式必须提供 url")
            html = await self._fetch_html(source.url)
            product = self._parse_html(html, source.url, job.category_hint)
            job.raw_product = product
            await self.log(job, f"URL 采集完成：标题 {len(product.raw_title)} 字，图片 {len(product.images)} 张")
            return self.store.save(job)

        if source.mode == SourceMode.html:
            if not source.html:
                raise ValueError("html 模式必须提供 html")
            product = self._parse_html(source.html, source.url or "", job.category_hint)
            job.raw_product = product
            await self.log(job, f"HTML 解析完成：标题 {len(product.raw_title)} 字，图片 {len(product.images)} 张")
            return self.store.save(job)

        raise ValueError(f"不支持的 source mode：{source.mode}")

    async def _fetch_html(self, url: str) -> str:
        settings = get_settings()
        headers = {
            "User-Agent": "Mozilla/5.0 BysheenAgent/1.0",
            "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.8",
        }
        async with httpx.AsyncClient(timeout=settings.request_timeout_seconds, follow_redirects=True) as client:
            resp = await client.get(url, headers=headers)
            resp.raise_for_status()
            return resp.text

    def _parse_html(self, html: str, base_url: str, category_hint: str | None) -> RawProduct:
        soup = BeautifulSoup(html, "lxml")
        title = self._first_meta(soup, ["og:title", "twitter:title"]) or normalize_space(soup.title.text if soup.title else "")
        desc = self._first_meta(soup, ["og:description", "description", "twitter:description"]) or self._extract_description(soup)
        images = self._extract_images(soup, base_url)
        price = self._extract_price(soup.get_text(" ", strip=True))
        supplier = self._extract_supplier(soup)
        specs = self._extract_specs(soup)

        return RawProduct(
            source_url=base_url or None,
            raw_title=title,
            raw_description=desc,
            price_cny=price,
            images=images,
            specs=specs,
            supplier_name=supplier,
            category_hint=category_hint,
        )

    def _first_meta(self, soup: BeautifulSoup, keys: List[str]) -> str:
        for key in keys:
            tag = soup.find("meta", attrs={"property": key}) or soup.find("meta", attrs={"name": key})
            if tag and tag.get("content"):
                return normalize_space(tag.get("content"))
        return ""

    def _extract_description(self, soup: BeautifulSoup) -> str:
        candidates = []
        for selector in ["#description", ".description", ".detail-desc", ".product-detail", "body"]:
            node = soup.select_one(selector)
            if node:
                text = normalize_space(node.get_text(" ", strip=True))
                if text:
                    candidates.append(text)
        return max(candidates, key=len)[:3000] if candidates else ""

    def _extract_images(self, soup: BeautifulSoup, base_url: str) -> List[str]:
        urls: list[str] = []
        for key in ["og:image", "twitter:image"]:
            meta = soup.find("meta", attrs={"property": key}) or soup.find("meta", attrs={"name": key})
            if meta and meta.get("content"):
                urls.append(urljoin(base_url, meta["content"]))
        for img in soup.find_all("img"):
            raw = img.get("data-src") or img.get("data-lazy-src") or img.get("src") or ""
            raw = raw.strip()
            if raw.startswith("//"):
                raw = "https:" + raw
            if raw.startswith("http") or raw.startswith("/"):
                urls.append(urljoin(base_url, raw))
        cleaned = [u for u in unique_keep_order(urls) if any(x in u.lower() for x in [".jpg", ".jpeg", ".png", ".webp", "alicdn", "img"]) ]
        return cleaned[: get_settings().max_images_per_product]

    def _extract_price(self, text: str) -> float | None:
        import re
        patterns = [r"¥\s*([0-9]+(?:\.[0-9]+)?)", r"￥\s*([0-9]+(?:\.[0-9]+)?)", r"价格\s*([0-9]+(?:\.[0-9]+)?)"]
        for pattern in patterns:
            m = re.search(pattern, text)
            if m:
                try:
                    return float(m.group(1))
                except ValueError:
                    return None
        return None

    def _extract_supplier(self, soup: BeautifulSoup) -> str | None:
        for selector in [".company-name", ".supplier-name", "[data-company-name]"]:
            node = soup.select_one(selector)
            if node:
                text = normalize_space(node.get_text(" ", strip=True) or node.get("data-company-name", ""))
                if text:
                    return text[:100]
        return None

    def _extract_specs(self, soup: BeautifulSoup) -> dict:
        specs: dict[str, str] = {}
        rows = soup.select("table tr")[:80]
        for row in rows:
            cells = [normalize_space(c.get_text(" ", strip=True)) for c in row.find_all(["td", "th"])]
            if len(cells) >= 2 and 1 <= len(cells[0]) <= 30 and 1 <= len(cells[1]) <= 100:
                specs[cells[0]] = cells[1]
        return specs
