from __future__ import annotations

from app.agents.base import Agent
from app.core.config import get_settings
from app.models.schemas import JobRecord, RawProduct
from app.utils.text_tools import clean_chinese_title, normalize_space, unique_keep_order


class CleanAgent(Agent):
    name = "CleanAgent"

    async def run(self, job: JobRecord) -> JobRecord:
        if not job.raw_product:
            raise ValueError("缺少 raw_product，无法清洗")

        p = job.raw_product
        await self.log(job, "开始清洗标题、描述、图片链接和规格")

        title = clean_chinese_title(p.raw_title)
        desc = normalize_space(p.raw_description)
        desc = self._remove_factory_noise(desc)
        images = self._clean_images(p.images)
        specs = {normalize_space(str(k)): normalize_space(str(v)) for k, v in p.specs.items() if normalize_space(str(k)) and normalize_space(str(v))}

        job.cleaned_product = RawProduct(
            source_url=p.source_url,
            raw_title=title,
            raw_description=desc[:4000],
            price_cny=p.price_cny,
            images=images,
            specs=specs,
            supplier_name=p.supplier_name,
            category_hint=p.category_hint or job.category_hint,
        )
        await self.log(job, f"清洗完成：保留图片 {len(images)} 张，规格 {len(specs)} 个")
        return self.store.save(job)

    def _remove_factory_noise(self, text: str) -> str:
        blacklist = ["营业执照", "生产许可证", "工厂实拍", "厂房", "招商加盟", "联系电话", "微信", "QQ", "阿里巴巴"]
        for item in blacklist:
            text = text.replace(item, "")
        return normalize_space(text)

    def _clean_images(self, images: list[str]) -> list[str]:
        valid = []
        for url in unique_keep_order(images):
            low = url.lower()
            if any(bad in low for bad in ["logo", "avatar", "qrcode", "icon", "gif"]):
                continue
            valid.append(url)
        return valid[: get_settings().max_images_per_product]
