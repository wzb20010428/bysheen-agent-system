from __future__ import annotations

from app.agents.clean_agent import CleanAgent
from app.agents.collector_agent import CollectorAgent
from app.agents.compliance_agent import ComplianceAgent
from app.agents.export_agent import ExportAgent
from app.agents.image_agent import ImageAgent
from app.agents.translate_agent import TranslateAgent
from app.core.store import store
from app.models.schemas import AgentStage, JobRecord, JobStatus


class ProductWorkflow:
    def __init__(self) -> None:
        self.collector = CollectorAgent()
        self.cleaner = CleanAgent()
        self.translator = TranslateAgent()
        self.image_agent = ImageAgent()
        self.compliance = ComplianceAgent()
        self.exporter = ExportAgent()

    async def run(self, job: JobRecord) -> JobRecord:
        try:
            job.status = JobStatus.running
            store.save(job)

            store.set_stage(job, AgentStage.collecting)
            job = await self.collector.run(job)

            store.set_stage(job, AgentStage.cleaning)
            job = await self.cleaner.run(job)

            store.set_stage(job, AgentStage.translating)
            job = await self.translator.run(job)

            store.set_stage(job, AgentStage.imaging)
            job = await self.image_agent.run(job)

            store.set_stage(job, AgentStage.compliance)
            job = await self.compliance.run(job)

            store.set_stage(job, AgentStage.exporting)
            job = await self.exporter.run(job)

            job.stage = AgentStage.done
            job.status = JobStatus.completed
            store.log(job, "Workflow: 全部 Agent 执行完成")
            return store.save(job)
        except Exception as exc:
            job.status = JobStatus.failed
            job.stage = AgentStage.failed
            job.error = str(exc)
            store.log(job, f"Workflow: 执行失败：{exc}")
            return store.save(job)
