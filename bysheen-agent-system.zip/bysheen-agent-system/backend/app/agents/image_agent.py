from __future__ import annotations

from pathlib import Path

from app.agents.base import Agent
from app.core.config import get_settings
from app.models.schemas import ImageAsset, JobRecord
from app.utils.image_tools import download_image, inspect_image, make_square_preview


class ImageAgent(Agent):
    name = "ImageAgent"

    async def run(self, job: JobRecord) -> JobRecord:
        if not job.cleaned_product:
            raise ValueError("缺少 cleaned_product，无法处理图片")
        await self.log(job, "开始下载、评分和基础处理商品图片")

        settings = get_settings()
        assets: list[ImageAsset] = []
        for url in job.cleaned_product.images[: settings.max_images_per_product]:
            asset = ImageAsset(original_url=url)
            local = await download_image(url, job.id)
            if local:
                width, height, score, notes = inspect_image(local)
                preview = make_square_preview(local)
                asset.local_path = str(preview or local)
                asset.public_url = f"{settings.public_base_url.rstrip('/')}/static/images/{job.id}/{Path(asset.local_path).name}"
                asset.width = width
                asset.height = height
                asset.score = score
                asset.notes = notes
            else:
                asset.notes.append("图片下载失败，导出时保留原始链接")
                asset.public_url = url
            assets.append(asset)

        assets.sort(key=lambda x: x.score, reverse=True)
        for idx, asset in enumerate(assets):
            asset.role = "main" if idx == 0 else "gallery"
        job.images = assets

        title = job.localized_product.title if job.localized_product else job.cleaned_product.raw_title
        job.scene_image_prompt = self._scene_prompt(title)
        job.marketing_image_prompt = self._marketing_prompt(title)

        await self.log(job, f"图片处理完成：{len(assets)} 张；主图分数 {assets[0].score if assets else 0:.1f}")
        return self.store.save(job)

    def _scene_prompt(self, title: str) -> str:
        return (
            f"Create a realistic lifestyle scene image for TikTok Shop Singapore, product: {title}. "
            "Bright clean home environment, natural daylight, premium ecommerce photography, no text, no watermark."
        )

    def _marketing_prompt(self, title: str) -> str:
        return (
            f"Create a square ecommerce marketing image for product: {title}. "
            "Clean composition, product hero shot, subtle background, space for short English selling points, no brand infringement."
        )
