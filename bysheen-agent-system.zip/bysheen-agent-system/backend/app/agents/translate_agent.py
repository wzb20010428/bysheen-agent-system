from __future__ import annotations

import json

from app.agents.base import Agent
from app.core.ai_client import AIClient
from app.models.schemas import JobRecord, LocalizedProduct
from app.utils.text_tools import build_fallback_keywords, guess_language_for_market


class TranslateAgent(Agent):
    name = "TranslateAgent"

    def __init__(self) -> None:
        super().__init__()
        self.ai = AIClient()

    async def run(self, job: JobRecord) -> JobRecord:
        if not job.cleaned_product:
            raise ValueError("缺少 cleaned_product，无法翻译")

        p = job.cleaned_product
        market = (job.target_market or "SG").upper()
        lang = guess_language_for_market(market)
        await self.log(job, f"开始面向 {market} 市场进行本地化，语言：{lang}")

        system = (
            "You are an expert TikTok Shop cross-border ecommerce listing specialist. "
            "Localize Chinese product information for the target market. "
            "Avoid exaggerated claims, medical claims, counterfeit claims, and platform-sensitive wording."
        )
        user = json.dumps(
            {
                "target_market": market,
                "language": lang,
                "category_hint": job.category_hint,
                "raw_title": p.raw_title,
                "raw_description": p.raw_description,
                "price_cny": p.price_cny,
                "specs": p.specs,
                "requirements": {
                    "title_max_chars": 140,
                    "bullet_points": 5,
                    "description_style": "clear TikTok Shop product description",
                    "keywords": 8,
                },
            },
            ensure_ascii=False,
        )
        schema = '{"title":"...","bullet_points":["..."],"description":"...","search_keywords":["..."],"category":"...","attributes":{}}'
        data, usage = await self.ai.chat_json(system, user, schema)
        job.token_usage.prompt_tokens += usage.prompt_tokens
        job.token_usage.completion_tokens += usage.completion_tokens
        job.token_usage.total_tokens += usage.total_tokens

        if data:
            localized = LocalizedProduct(
                target_market=market,
                language=lang,
                title=str(data.get("title", ""))[:180],
                bullet_points=[str(x)[:180] for x in data.get("bullet_points", [])][:8],
                description=str(data.get("description", ""))[:5000],
                search_keywords=[str(x)[:50] for x in data.get("search_keywords", [])][:12],
                category=str(data.get("category", job.category_hint or ""))[:120],
                attributes=data.get("attributes", {}) if isinstance(data.get("attributes", {}), dict) else {},
            )
        else:
            localized = self._fallback_localize(job)
            await self.log(job, "未配置 AI_API_KEY，已使用本地 fallback 生成英文草稿")

        if not localized.bullet_points:
            localized.bullet_points = self._fallback_bullets(p.raw_title)
        if not localized.search_keywords:
            localized.search_keywords = build_fallback_keywords(localized.title or p.raw_title)

        job.localized_product = localized
        await self.log(job, f"本地化完成：标题 {len(localized.title)} 字，卖点 {len(localized.bullet_points)} 条")
        return self.store.save(job)

    def _fallback_localize(self, job: JobRecord) -> LocalizedProduct:
        p = job.cleaned_product
        assert p is not None
        lang = guess_language_for_market(job.target_market)
        title = p.raw_title
        # A minimal non-AI fallback. Production should use AI translation or a translation API.
        if lang == "en":
            title = f"Premium {p.raw_title} for Home Use"[:140]
            desc = (
                f"Product: {p.raw_title}.\n\n"
                f"This item is suitable for daily home and lifestyle use. "
                f"Please check the specifications before purchase.\n\n"
                f"Specifications: " + ", ".join([f"{k}: {v}" for k, v in p.specs.items()])
            )
        else:
            desc = p.raw_description
        return LocalizedProduct(
            target_market=job.target_market,
            language=lang,
            title=title,
            bullet_points=self._fallback_bullets(p.raw_title),
            description=desc[:3000],
            search_keywords=build_fallback_keywords(p.raw_title),
            category=p.category_hint or job.category_hint or "",
            attributes=p.specs,
        )

    def _fallback_bullets(self, raw_title: str) -> list[str]:
        return [
            "Practical design for everyday use",
            "Selected material with reliable structure",
            "Easy to match with different home scenarios",
            "Suitable for TikTok Shop cross-border listing",
            f"Based on source product: {raw_title[:60]}",
        ]
