from __future__ import annotations

import asyncio
import uuid

from app.agents.workflow import ProductWorkflow
from app.core.store import store
from app.models.schemas import JobCreateRequest, JobRecord, RunResponse, JobStatus


class JobRunner:
    def create_job(self, req: JobCreateRequest) -> JobRecord:
        job = JobRecord(
            id=uuid.uuid4().hex[:16],
            source=req.source,
            target_market=req.target_market.upper(),
            category_hint=req.category_hint,
        )
        return store.save(job)

    async def run_job(self, job_id: str) -> RunResponse:
        job = store.get(job_id)
        if not job:
            raise ValueError("任务不存在")
        if job.status == JobStatus.running:
            return RunResponse(job_id=job_id, status=job.status, message="任务正在运行中")
        workflow = ProductWorkflow()
        asyncio.create_task(workflow.run(job))
        return RunResponse(job_id=job_id, status=JobStatus.running, message="任务已开始执行")


job_runner = JobRunner()
