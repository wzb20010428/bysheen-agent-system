from __future__ import annotations

from datetime import datetime
from enum import Enum
from typing import Any, Dict, List, Optional
from pydantic import BaseModel, Field, HttpUrl


class SourceMode(str, Enum):
    url = "url"
    html = "html"
    manual = "manual"


class JobStatus(str, Enum):
    pending = "pending"
    running = "running"
    completed = "completed"
    failed = "failed"


class AgentStage(str, Enum):
    created = "created"
    collecting = "collecting"
    cleaning = "cleaning"
    translating = "translating"
    imaging = "imaging"
    compliance = "compliance"
    exporting = "exporting"
    done = "done"
    failed = "failed"


class ProductSource(BaseModel):
    mode: SourceMode = SourceMode.manual
    url: Optional[str] = None
    html: Optional[str] = None
    manual_product: Optional["RawProduct"] = None


class RawProduct(BaseModel):
    source_url: Optional[str] = None
    raw_title: str = ""
    raw_description: str = ""
    price_cny: Optional[float] = None
    images: List[str] = Field(default_factory=list)
    specs: Dict[str, Any] = Field(default_factory=dict)
    supplier_name: Optional[str] = None
    category_hint: Optional[str] = None


class LocalizedProduct(BaseModel):
    target_market: str = "SG"
    language: str = "en"
    title: str = ""
    bullet_points: List[str] = Field(default_factory=list)
    description: str = ""
    search_keywords: List[str] = Field(default_factory=list)
    category: str = ""
    attributes: Dict[str, Any] = Field(default_factory=dict)


class ImageAsset(BaseModel):
    original_url: str
    local_path: Optional[str] = None
    public_url: Optional[str] = None
    width: Optional[int] = None
    height: Optional[int] = None
    score: float = 0
    role: str = "gallery"  # main, gallery, detail
    notes: List[str] = Field(default_factory=list)


class ComplianceIssue(BaseModel):
    level: str = "warning"  # info, warning, error
    code: str
    message: str
    suggestion: Optional[str] = None


class TokenUsage(BaseModel):
    prompt_tokens: int = 0
    completion_tokens: int = 0
    total_tokens: int = 0
    estimated_cost_usd: float = 0


class JobCreateRequest(BaseModel):
    source: ProductSource
    target_market: str = "SG"
    category_hint: Optional[str] = "Home & Kitchen"
    auto_run: bool = False


class JobRecord(BaseModel):
    id: str
    status: JobStatus = JobStatus.pending
    stage: AgentStage = AgentStage.created
    source: ProductSource
    target_market: str = "SG"
    category_hint: Optional[str] = None

    raw_product: Optional[RawProduct] = None
    cleaned_product: Optional[RawProduct] = None
    localized_product: Optional[LocalizedProduct] = None
    images: List[ImageAsset] = Field(default_factory=list)
    compliance_issues: List[ComplianceIssue] = Field(default_factory=list)
    export_file: Optional[str] = None

    scene_image_prompt: Optional[str] = None
    marketing_image_prompt: Optional[str] = None

    token_usage: TokenUsage = Field(default_factory=TokenUsage)
    logs: List[str] = Field(default_factory=list)
    error: Optional[str] = None
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)


class JobListResponse(BaseModel):
    items: List[JobRecord]


class RunResponse(BaseModel):
    job_id: str
    status: JobStatus
    message: str


ProductSource.model_rebuild()
