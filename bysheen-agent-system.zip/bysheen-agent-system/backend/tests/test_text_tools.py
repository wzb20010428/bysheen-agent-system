from app.utils.text_tools import clean_chinese_title, unique_keep_order


def test_clean_title():
    assert "厂家直销" not in clean_chinese_title("厂家直销 不锈钢厨房置物架")


def test_unique_keep_order():
    assert unique_keep_order(["a", "a", "b"]) == ["a", "b"]
