<template>
  <div class="page">
    <section class="hero">
      <div class="card">
        <h1>多 Agent 协同的跨境商品内容生产系统</h1>
        <p class="muted">
          面向 TikTok Shop 跨境卖家：1688 采集、商品清洗、标题/描述本地化、图片评分处理、合规检查、Excel 批量导出。
        </p>
        <div class="pipeline">
          <div v-for="s in steps" :key="s.key" class="step" :class="stepClass(s.key)">{{ s.name }}</div>
        </div>
      </div>
      <div class="card">
        <h2>系统状态</h2>
        <p><span class="status" :class="currentJob?.status">{{ currentJob?.status || 'idle' }}</span></p>
        <p class="muted">当前任务：{{ currentJob?.id || '暂无' }}</p>
        <div class="actions">
          <button class="ghost" @click="loadJobs">刷新任务</button>
          <button class="secondary" @click="createDemo">创建 Demo</button>
          <a v-if="currentJob?.export_file" :href="exportUrl(currentJob.id)" target="_blank"><button class="primary">下载 Excel</button></a>
        </div>
      </div>
    </section>

    <section class="grid">
      <div class="card">
        <h2>创建商品处理任务</h2>
        <div class="form-row">
          <label>输入模式</label>
          <select v-model="mode">
            <option value="manual">手动商品信息</option>
            <option value="url">商品 URL</option>
            <option value="html">粘贴 HTML</option>
          </select>
        </div>
        <div class="form-row">
          <label>目标市场</label>
          <select v-model="form.target_market">
            <option value="SG">新加坡 SG / English</option>
            <option value="MY">马来西亚 MY / English</option>
            <option value="PH">菲律宾 PH / English</option>
            <option value="TH">泰国 TH / Thai</option>
            <option value="VN">越南 VN / Vietnamese</option>
            <option value="ID">印尼 ID / Indonesian</option>
          </select>
        </div>
        <div class="form-row">
          <label>类目提示</label>
          <input v-model="form.category_hint" placeholder="例如：Home & Kitchen" />
        </div>

        <template v-if="mode === 'url'">
          <div class="form-row">
            <label>1688/商品 URL</label>
            <input v-model="url" placeholder="https://detail.1688.com/..." />
          </div>
        </template>

        <template v-if="mode === 'html'">
          <div class="form-row">
            <label>商品页 HTML</label>
            <textarea v-model="html" placeholder="粘贴商品详情页 HTML"></textarea>
          </div>
        </template>

        <template v-if="mode === 'manual'">
          <div class="form-row">
            <label>中文标题</label>
            <input v-model="manual.raw_title" placeholder="不锈钢厨房置物架 多层收纳架" />
          </div>
          <div class="form-row">
            <label>中文描述</label>
            <textarea v-model="manual.raw_description" placeholder="材质、尺寸、使用场景、卖点..."></textarea>
          </div>
          <div class="form-row">
            <label>价格 CNY</label>
            <input v-model.number="manual.price_cny" type="number" />
          </div>
          <div class="form-row">
            <label>图片 URL，每行一个</label>
            <textarea v-model="imageText" placeholder="https://...jpg"></textarea>
          </div>
          <div class="form-row">
            <label>规格 JSON</label>
            <textarea v-model="specText"></textarea>
          </div>
        </template>

        <div class="actions">
          <button class="primary" @click="createAndRun" :disabled="loading">创建并运行</button>
          <button class="ghost" @click="createOnly" :disabled="loading">只创建</button>
        </div>
        <p class="muted">{{ tip }}</p>
      </div>

      <div class="result">
        <div class="card">
          <h2>任务列表</h2>
          <div v-if="jobs.length === 0" class="muted">暂无任务</div>
          <div v-for="job in jobs" :key="job.id" class="kv" @click="selectJob(job.id)" style="cursor:pointer">
            <div><strong>{{ job.id }}</strong></div>
            <div>
              <span class="status" :class="job.status">{{ job.status }}</span>
              <span class="badge">{{ job.stage }}</span>
              <span class="badge">{{ job.target_market }}</span>
              <div class="muted">{{ job.localized_product?.title || job.cleaned_product?.raw_title || job.raw_product?.raw_title || '未生成标题' }}</div>
            </div>
          </div>
        </div>

        <div v-if="currentJob" class="card">
          <h2>结果预览</h2>
          <div class="kv"><strong>标题</strong><div>{{ currentJob.localized_product?.title || '-' }}</div></div>
          <div class="kv"><strong>类目</strong><div>{{ currentJob.localized_product?.category || currentJob.category_hint || '-' }}</div></div>
          <div class="kv"><strong>卖点</strong><div><span class="badge" v-for="b in currentJob.localized_product?.bullet_points || []" :key="b">{{ b }}</span></div></div>
          <div class="kv"><strong>关键词</strong><div><span class="badge" v-for="k in currentJob.localized_product?.search_keywords || []" :key="k">{{ k }}</span></div></div>
          <div class="kv"><strong>描述</strong><div style="white-space:pre-wrap">{{ currentJob.localized_product?.description || '-' }}</div></div>
          <div class="kv"><strong>Token</strong><div>{{ currentJob.token_usage?.total_tokens || 0 }}</div></div>
        </div>

        <div v-if="currentJob?.images?.length" class="card">
          <h2>图片</h2>
          <div class="image-list">
            <div v-for="img in currentJob.images" :key="img.original_url" class="image-tile">
              <img :src="img.public_url || img.original_url" />
              <div><span class="badge">{{ img.role }}</span><span class="badge">{{ Math.round(img.score) }}</span></div>
            </div>
          </div>
        </div>

        <div v-if="currentJob" class="card">
          <h2>合规问题</h2>
          <div v-if="!currentJob.compliance_issues?.length" class="muted">暂无问题</div>
          <div class="issues">
            <div v-for="issue in currentJob.compliance_issues" :key="issue.code + issue.message" class="issue" :class="issue.level">
              <strong>[{{ issue.level }}] {{ issue.code }}</strong>：{{ issue.message }}
              <div class="muted" v-if="issue.suggestion">建议：{{ issue.suggestion }}</div>
            </div>
          </div>
        </div>

        <div v-if="currentJob" class="card">
          <h2>AI 图片 Prompt</h2>
          <div class="kv"><strong>场景图</strong><div>{{ currentJob.scene_image_prompt || '-' }}</div></div>
          <div class="kv"><strong>营销图</strong><div>{{ currentJob.marketing_image_prompt || '-' }}</div></div>
        </div>

        <div v-if="currentJob" class="card">
          <h2>日志</h2>
          <div class="log">
            <div v-for="line in currentJob.logs" :key="line">{{ line }}</div>
            <div v-if="currentJob.error" style="color:#fecaca">ERROR: {{ currentJob.error }}</div>
          </div>
        </div>
      </div>
    </section>
  </div>
</template>

<script setup>
import { computed, onMounted, reactive, ref } from 'vue'
import { api, exportUrl } from './api'

const loading = ref(false)
const jobs = ref([])
const currentJob = ref(null)
const mode = ref('manual')
const url = ref('')
const html = ref('')
const tip = ref('')
const imageText = ref('')
const specText = ref('{"材质":"不锈钢","层数":"4层","颜色":"银色"}')
const form = reactive({ target_market: 'SG', category_hint: 'Home & Kitchen' })
const manual = reactive({
  source_url: 'https://detail.1688.com/demo',
  raw_title: '厂家直销 不锈钢厨房置物架 多层收纳架 落地微波炉架',
  raw_description: '厨房收纳置物架，层板结实，适合厨房、客厅、储物间使用。材质：不锈钢。层数：4层。颜色：银色。',
  price_cny: 39.9,
})

const steps = [
  { key: 'collecting', name: '采集' },
  { key: 'cleaning', name: '清洗' },
  { key: 'translating', name: '翻译' },
  { key: 'imaging', name: '图片' },
  { key: 'compliance', name: '合规' },
  { key: 'exporting', name: '导出' },
]
const order = steps.map(s => s.key)
function stepClass(key) {
  const stage = currentJob.value?.stage
  if (!stage) return ''
  if (stage === key) return 'active'
  if (stage === 'done') return 'done'
  return order.indexOf(key) < order.indexOf(stage) ? 'done' : ''
}

function buildPayload(autoRun = false) {
  let source = { mode: mode.value }
  if (mode.value === 'url') source.url = url.value
  if (mode.value === 'html') source.html = html.value
  if (mode.value === 'manual') {
    let specs = {}
    try { specs = JSON.parse(specText.value || '{}') } catch { specs = {} }
    source.manual_product = {
      ...manual,
      images: imageText.value.split('\n').map(x => x.trim()).filter(Boolean),
      specs,
      category_hint: form.category_hint,
    }
  }
  return { source, target_market: form.target_market, category_hint: form.category_hint, auto_run: autoRun }
}

async function createOnly() {
  loading.value = true
  tip.value = ''
  try {
    const { data } = await api.post('/api/jobs', buildPayload(false))
    currentJob.value = data
    await loadJobs()
    tip.value = '任务已创建'
  } catch (e) {
    tip.value = e.response?.data?.detail || e.message
  } finally { loading.value = false }
}

async function createAndRun() {
  loading.value = true
  tip.value = ''
  try {
    const { data } = await api.post('/api/jobs', buildPayload(false))
    currentJob.value = data
    await api.post(`/api/jobs/${data.id}/run`)
    tip.value = '任务已开始运行'
    poll(data.id)
    await loadJobs()
  } catch (e) {
    tip.value = e.response?.data?.detail || e.message
  } finally { loading.value = false }
}

async function createDemo() {
  const { data } = await api.post('/api/demo-job')
  currentJob.value = data
  await api.post(`/api/jobs/${data.id}/run`)
  poll(data.id)
  await loadJobs()
}

async function loadJobs() {
  const { data } = await api.get('/api/jobs')
  jobs.value = data.items
  if (!currentJob.value && jobs.value.length) currentJob.value = jobs.value[0]
}

async function selectJob(id) {
  const { data } = await api.get(`/api/jobs/${id}`)
  currentJob.value = data
}

async function poll(id) {
  let count = 0
  const timer = setInterval(async () => {
    count++
    await selectJob(id)
    await loadJobs()
    if (!['running', 'pending'].includes(currentJob.value?.status) || count > 120) clearInterval(timer)
  }, 1500)
}

onMounted(loadJobs)
</script>
