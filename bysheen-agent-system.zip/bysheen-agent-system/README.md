# Bysheen 多 Agent 协同的跨境商品内容生产系统

这是一个可运行的完整 MVP 项目，用于把 1688/中文货源商品转成 TikTok Shop 跨境上架素材：采集 → 清洗 → 翻译本地化 → 图片处理/评分 → 合规检查 → 导出 TikTok 批量上架 Excel。

> 说明：本项目不包含验证码绕过、反爬绕过、Cookie 窃取、平台风控规避等能力。采集仅用于你有权限访问的公开商品页或手动粘贴 HTML/商品信息。TikTok 上架优先使用官方批量导入模板导出。

## 项目结构

```text
bysheen-agent-system/
├── backend/                 # FastAPI 后端，多 Agent 工作流
│   ├── app/
│   │   ├── agents/          # 采集/清洗/翻译/图片/合规/导出 Agent
│   │   ├── core/            # 配置、AI Client、JSON 存储
│   │   ├── models/          # Pydantic 数据模型
│   │   ├── services/        # Job Runner
│   │   ├── utils/           # 图片与文本工具
│   │   └── main.py          # API 入口
│   ├── requirements.txt
│   └── Dockerfile
├── frontend/                # Vue 3 前端控制台
│   ├── src/
│   ├── package.json
│   └── Dockerfile
├── docker-compose.yml
└── .env.example
```

## 快速启动：本地运行

### 1. 启动后端

```bash
cd backend
python -m venv .venv
# Windows: .venv\Scripts\activate
source .venv/bin/activate
pip install -r requirements.txt
cp ../.env.example .env
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

打开接口文档：`http://localhost:8000/docs`

### 2. 启动前端

```bash
cd frontend
npm install
npm run dev
```

打开控制台：`http://localhost:5173`

## 快速启动：Docker

```bash
cp .env.example .env
docker compose up --build
```

前端：`http://localhost:5173`  
后端：`http://localhost:8000`

## AI 配置

默认不配置 AI 也能跑通流程，但翻译/生成结果会使用 fallback。配置 OpenAI-compatible 接口后，翻译和文案本地化效果更好。

编辑 `.env`：

```env
AI_BASE_URL=https://api.openai.com/v1
AI_API_KEY=你的API_KEY
AI_MODEL=gpt-4o-mini
```

如果你用其他兼容 OpenAI Chat Completions 的网关，也可以修改 `AI_BASE_URL`。

## API 示例

### 创建任务

```bash
curl -X POST http://localhost:8000/api/jobs \
  -H "Content-Type: application/json" \
  -d '{
    "source": {
      "mode": "manual",
      "manual_product": {
        "source_url": "https://detail.1688.com/example",
        "raw_title": "不锈钢厨房置物架 多层收纳架",
        "raw_description": "厨房收纳，承重强，适合跨境电商销售。",
        "price_cny": 39.9,
        "images": ["https://example.com/product.jpg"],
        "specs": {"材质": "不锈钢", "层数": "4层"}
      }
    },
    "target_market": "SG",
    "category_hint": "Home & Kitchen"
  }'
```

### 运行任务

```bash
curl -X POST http://localhost:8000/api/jobs/{job_id}/run
```

### 查询任务

```bash
curl http://localhost:8000/api/jobs/{job_id}
```

### 下载 Excel

```bash
curl -L http://localhost:8000/api/jobs/{job_id}/export -o tiktok_import.xlsx
```

## Agent 流程

1. **CollectorAgent**：支持 URL、HTML、手动商品 JSON 三种输入。
2. **CleanAgent**：去重图片、清洗标题、过滤工厂/中文营销噪声。
3. **TranslateAgent**：按目标市场生成标题、卖点、详情描述。
4. **ImageAgent**：图片下载、主图评分、基础处理、生成场景图/营销图 Prompt。
5. **ComplianceAgent**：检查标题长度、敏感词、图片数量、描述完整度。
6. **ExportAgent**：导出 TikTok 批量上架 Excel 模板。

## 后续可扩展方向

- 接入真实 TikTok Shop Open API 或官方模板字段。
- 接入 OCR，自动识别并擦除中文文字/水印。
- 接入对象存储 COS/S3，把处理后的图片变成可访问链接。
- 接入浏览器人工辅助上架，但不要绕过验证码或平台风控。
- 增加多店铺、多国家站点、用户额度、Token 统计和 SaaS 计费。
